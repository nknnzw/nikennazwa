var selectedImage = "";

var animalImages = document.querySelectorAll("#animals div");
for (var i = 0; i < animalImages.length; i++) {
    animalImages[i].addEventListener("click", function () {
        selectedImage = this.className;
    });
}

function cekGambar() {
    if (selectedImage === "kuda") {
        window.location.href = "benarSalahh1.html"; 
    } else {
        alert("Maaf, jawaban Anda salah. Silakan coba lagi.");
    }
}
